package dip.shaha;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Argregister
 */
public class Argregister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Argregister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		int agid=0;
		 String anamne= request.getParameter("anamne");		
		 String email= request.getParameter("email");
		 String pass= request.getParameter("pass");
		 long mbn= Long.parseLong(request.getParameter("mbn"));
		 String vil= request.getParameter("vil");
		 String dis= request.getParameter("dis");
		  Connection con=DBConnection.connect();		
			try {
				PreparedStatement ps = con.prepareStatement("insert into arogravibhag values(?,?,?,?,?,?,?)");
				ps.setInt(1,agid);
				ps.setString(2,anamne);
				ps.setString(3,email);
				ps.setString(4, pass);			
				ps.setLong(5, mbn);
				ps.setString(6, vil);
				ps.setString(7,dis);
				int i = ps.executeUpdate();
				if(i>0){
					response.sendRedirect("index.html");
				}else
					response.sendRedirect("avregister.html");				
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}

}
