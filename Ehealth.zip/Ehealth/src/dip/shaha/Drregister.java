package dip.shaha;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Drregister
 */
public class Drregister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Drregister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		int did=0;
		 String dnamne= request.getParameter("dnamne");		
		 String email= request.getParameter("email");
		 String pass= request.getParameter("pass");
		 long mbn= Long.parseLong(request.getParameter("mbn"));
		 String city= request.getParameter("city");
		 String spec= request.getParameter("spec");
		 String dise= request.getParameter("dise");
		  Connection con=DBConnection.connect();		
			try {
				PreparedStatement ps = con.prepareStatement("insert into doctor values(?,?,?,?,?,?,?,?)");
				ps.setInt(1,did);
				ps.setString(2,dnamne);
				ps.setString(3,email);
				ps.setString(4, pass);			
				ps.setLong(5, mbn);
				ps.setString(6, city);
				ps.setString(7, spec);
				ps.setString(8,dise);
				int i = ps.executeUpdate();
				if(i>0){
					response.sendRedirect("index.html");
				}else
					response.sendRedirect("doctorregister.html");				
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}

}
