package dip.shaha;

public class values {
	
 static String  email;

public static String getEmail() {
	return email;
}

public static void setEmail(String email) {
	values.email = email;
}
}
