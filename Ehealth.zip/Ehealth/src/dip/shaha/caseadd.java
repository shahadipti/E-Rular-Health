package dip.shaha;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class caseadd
 */
public class caseadd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public caseadd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		try {
			Connection con=DBConnection.connect();
			int pid=0;
			String name=request.getParameter("name");
			String age=request.getParameter("age");
			String gender=request.getParameter("gender");
			String add=request.getParameter("add");
			String mob=request.getParameter("mob");
			String sym1=request.getParameter("sym1");
			String sym2=request.getParameter("sym2");
			String sym3=request.getParameter("sym3");
			System.out.println("1");

			PreparedStatement ps = con.prepareStatement("select * from dset where Sympt1=? and Sympt2=? and Sympt3=?");
			ps.setString(1, sym1);
			ps.setString(2, sym2);
			ps.setString(3, sym3);
			ResultSet rs=ps.executeQuery();
			System.out.println(sym1);
			System.out.println(sym2);
			System.out.println(sym3);

			while(rs.next())
			{
				System.out.println("2");
				String dis= rs.getString("disea");
				System.out.println(dis);
				//PreparedStatement ps1 = con.prepareStatement("select agid from arogyavibhag where email=? ");
				////ps1.setString(1, values.getEmail());
				//ResultSet rs2=ps1.executeQuery();
				//while(rs2.next())
				//{
				PreparedStatement ps3=con.prepareStatement("select * from doctor where diseasedtreat=? ");
				ps3.setString(1, dis);
				ResultSet rs1=ps3.executeQuery();
				
				while(rs1.next())
				{
					int drid=rs1.getInt("did");
					System.out.println(drid);
					String uDisease=rs1.getString("diseasedtreat");
					System.out.println(uDisease);
					PreparedStatement ps2 = con.prepareStatement("insert into patient values(?,?,?,?,?,?,?,?,?,?,?) ");
					//ps2.setInt(1, id);
					ps2.setInt(1, pid);
					
					

					ps2.setString(2, name);
					ps2.setString(3, age);
					ps2.setString(4, gender);
					ps2.setString(5, add);
					ps2.setString(6, mob);
					ps2.setString(7, sym1);
					ps2.setString(8, sym2);
					ps2.setString(9, sym3);
					ps2.setString(10, uDisease);
					ps2.setInt(11, drid);
					int i=ps2.executeUpdate();
					if (i>0)
					{
												
						response.sendRedirect("index.html");
							
						}
					}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	}

